package com.udusug.voting.exception;

public class AccountLockedException extends RuntimeException
{
    public AccountLockedException(String message)
    {
        super(message);
    }
}
