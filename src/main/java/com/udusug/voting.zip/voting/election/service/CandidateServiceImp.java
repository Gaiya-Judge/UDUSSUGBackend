package com.udusug.voting.election.service;

import com.udusug.voting.admin.dto.AdminCandidateResponse;
import com.udusug.voting.admin.dto.AdminWriteResponse;
import com.udusug.voting.admin.dto.UpdateCandidateRequest;
import com.udusug.voting.admin.entity.Admin;
import com.udusug.voting.admin.repository.AdminRepository;
import com.udusug.voting.audit.entity.AuditLog;
import com.udusug.voting.audit.repository.AuditLogRepository;
import com.udusug.voting.election.dto.CandidateResponse;
import com.udusug.voting.election.entity.Candidate;
import com.udusug.voting.election.entity.Election;
import com.udusug.voting.election.entity.Position;
import com.udusug.voting.election.repository.CandidateRepository;
import com.udusug.voting.election.repository.ElectionRepository;
import com.udusug.voting.election.repository.PositionRepository;
import com.udusug.voting.exception.ApiException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CandidateServiceImp implements CandidateService {

    private final CandidateRepository candidateRepository;
    private final PositionRepository positionRepository;
    private final ElectionRepository electionRepository;
    private final AdminRepository adminRepository;
    private final AuditLogRepository auditLogRepository;

    @Override
    public List<CandidateResponse> getAllCandidates(Long positionId) {
        log.info("Fetching candidates for position filter: {}", positionId);

        Optional<Election> latestElectionOpt = electionRepository.findFirstByOrderByIdDesc();
        if (latestElectionOpt.isEmpty()) {
            log.info("No election found. Returning empty candidate list.");
            return Collections.emptyList();
        }

        String currentSessionLabel = latestElectionOpt.get().getSessionLabel();
        List<Candidate> candidates;

        if (positionId != null) {
            candidates = candidateRepository.findByPosition_IdAndPosition_SessionLabel(positionId, currentSessionLabel);
        } else {
            candidates = candidateRepository.findByPosition_SessionLabel(currentSessionLabel);
        }

        return candidates.stream()
                .map(this::mapToPublicResponse)
                .toList();
    }

    @Override
    public List<AdminCandidateResponse> getAllCandidatesForAdmin() {
        log.info("Admin request: fetching candidate list");
        return candidateRepository.findAll().stream()
                .map(this::mapToAdminResponse)
                .toList();
    }

    @Override
    @Transactional
    public AdminWriteResponse updateCandidate(String adminEmail, Long candidateId, UpdateCandidateRequest request) {

        log.info("Admin [{}] updating candidate with ID: {}", adminEmail, candidateId);

        Admin admin = findAdminByEmail(adminEmail);

        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Candidate not found with ID: " + candidateId));

        Position position = positionRepository.findById(request.getPositionId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Position not found with ID: " + request.getPositionId()));

        candidate.setName(request.getName());
        candidate.setPosition(position);

        candidateRepository.save(candidate);

        recordAudit(admin, "UPDATE_CANDIDATE",
                String.format("Updated candidate '%s' (ID: %d) under position '%s' (ID: %d)",
                        candidate.getName(), candidate.getId(), position.getName(), position.getId()));

        return AdminWriteResponse.builder()
                .message("Candidate updated successfully")
                .id(candidate.getId())
                .build();
    }

    @Override
    @Transactional
    public AdminWriteResponse deleteCandidate(String adminEmail, Long candidateId) {

        log.info("Admin [{}] deleting candidate with ID: {}", adminEmail, candidateId);

        Admin admin = findAdminByEmail(adminEmail);

        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Candidate not found with ID: " + candidateId));

        candidateRepository.delete(candidate);

        recordAudit(admin, "DELETE_CANDIDATE",
                String.format("Deleted candidate '%s' (ID: %d)", candidate.getName(), candidateId));

        return AdminWriteResponse.builder()
                .message("Candidate removed successfully")
                .id(candidateId)
                .build();
    }

    private CandidateResponse mapToPublicResponse(Candidate candidate) {
        return CandidateResponse.builder()
                .candidateId(candidate.getId())
                .name(candidate.getName())
                .positionId(candidate.getPosition().getId())
                .positionName(candidate.getPosition().getName())
                .build();
    }

    private AdminCandidateResponse mapToAdminResponse(Candidate candidate) {
        return AdminCandidateResponse.builder()
                .id(candidate.getId())
                .name(candidate.getName())
                .positionId(candidate.getPosition().getId())
                .positionName(candidate.getPosition().getName())
                .build();
    }

    private Admin findAdminByEmail(String email) {
        return adminRepository.findByEmail(email)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Admin account not found for email: " + email));
    }

    private void recordAudit(Admin admin, String action, String details) {
        AuditLog auditLog = AuditLog.builder()
                .admin(admin)
                .action(action)
                .details(details)
                .build();
        auditLogRepository.save(auditLog);
    }
}
