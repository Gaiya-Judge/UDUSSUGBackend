package com.udusug.voting.election.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CandidateResponse {

    private Long candidateId;
    private String name;
    private String department;
    private Long positionId;
    private String positionName;
}
